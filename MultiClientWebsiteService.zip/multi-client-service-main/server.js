require('dotenv').config();
const express = require('express');
const multer = require('multer');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY); // Stripe Integration
const { Resend } = require('resend');
const resend = new Resend(process.env.RESEND_API_KEY);
const nodemailer = require('nodemailer');

// 1. Setup Express and Middleware
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 2. Set up Multer for Image Uploads
const upload = multer({ dest: 'uploads/' }); 

// 3. Setup Nodemailer Transporter (Free Email Receipts)
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});


// 4. Initialize TiDB cloud Connection Pool
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  ssl: {
    minVersion: 'TLSv1.2',
    rejectUnauthorized: true
  }
});


// 5. Authentication Middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; 

  if (!token) return res.status(401).json({ error: "Access denied. No token provided." });

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: "Invalid or expired token" });
    req.user = user;
    next();
  });
};

// ---------------- MERCHANT SIGNUP ----------------
app.post('/api/auth/register-merchant', async (req, res) => {
  const { email, password, fullName, businessName, categoryId, description = null} = req.body;
  
  try {
    const userId = crypto.randomUUID();
    const hashedPassword = await bcrypt.hash(password, 10);

    const connection = await pool.getConnection();
    await connection.beginTransaction();

    try {
      await connection.execute(
        `INSERT INTO profiles (id, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, 'merchant')`,
        [userId, email, hashedPassword, fullName]
      );

      await connection.execute(
        `INSERT INTO merchants (id, business_name, category_id, description, availability) VALUES (?, ?, ?, ?, ?)`,
        [userId, businessName, categoryId, description, JSON.stringify({ monday: "9am-5pm" })]
      );

      await connection.commit();
      connection.release();
      
      res.status(201).json({ message: "Merchant registered successfully!" });
    } catch (err) {
      await connection.rollback();
      connection.release();
      throw err;
    }
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.status(400).json({ error: "Email already exists" });
    res.status(500).json({ error: err.message });
  }
});

// ---------------- USER LOGIN ----------------
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const [rows] = await pool.execute(`SELECT id, password_hash, role FROM profiles WHERE email = ?`, [email]);
    if (rows.length === 0) return res.status(404).json({ error: "User not found" });

    const user = rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) return res.status(401).json({ error: "Invalid password" });

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '24h' });
    
    res.status(200).json({ message: "Login successful", token, role: user.role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------- ADD A SERVICE ----------------
app.post('/api/merchants/services', authenticateToken, upload.single('image'), async (req, res) => {
    if (req.user.role !== 'merchant') {
        return res.status(403).json({ error: "Only merchants can add services" });
    }

    const { title, description = null, price, duration_minutes } = req.body;
    const serviceId = crypto.randomUUID();
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : null;

    try {
        await pool.execute(
            `INSERT INTO services (id, merchant_id, title, description, price, duration_minutes, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [serviceId, req.user.id, title, description, price, duration_minutes || 60, imageUrl]
        );
        res.status(201).json({ message: "Service added successfully", serviceId, imageUrl });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// ---------------- SEARCH MARKETPLACE ----------------
app.get('/api/marketplace', async (req, res) => {
  try {
    const [rows] = await pool.execute(`
      SELECT m.id, m.business_name, c.name as category, s.id as service_id, s.title as service, s.price, s.description, s.image_url 
      FROM merchants m 
      LEFT JOIN categories c ON m.category_id = c.id
      LEFT JOIN services s ON m.id = s.merchant_id
      WHERE s.id IS NOT NULL
    `);
    res.status(200).json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------- CHECKOUT: CREATE STRIPE SESSION ----------------
app.post('/api/checkout/create-session', async (req, res) => {
    const { serviceId, customerEmail } = req.body;

    try {
        const [services] = await pool.execute('SELECT * FROM services WHERE id = ?', [serviceId]);
        if (services.length === 0) return res.status(404).json({ error: "Service not found" });
        const service = services[0];

        const orderId = crypto.randomUUID();

        // Create Stripe Session
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: [{
                price_data: {
                    currency: 'usd',
                    product_data: { 
                        name: service.title,
                        description: service.description || 'Service booking via ServiceHub'
                    },
                    unit_amount: Math.round(service.price * 100), 
                },
                quantity: 1,
            }],
            mode: 'payment',
            customer_email: customerEmail,
            success_url: `http://localhost:${process.env.PORT || 3000}/success.html?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `http://localhost:${process.env.PORT || 3000}/cancel.html`,
        });

        // Track order in DB
        await pool.execute(
            `INSERT INTO orders (id, merchant_id, customer_email, service_id, amount, payment_status, stripe_session_id) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [orderId, service.merchant_id, customerEmail, service.id, service.price, 'pending', session.id]
        );

        res.status(200).json({ url: session.url });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// ---------------- CHECKOUT: VERIFY & SEND RECEIPTS ----------------
app.post('/api/checkout/verify-payment', async (req, res) => {
    const { session_id } = req.body;

    try {
        const session = await stripe.checkout.sessions.retrieve(session_id);
        
        if (session.payment_status === 'paid') {
            await pool.execute('UPDATE orders SET payment_status = "paid" WHERE stripe_session_id = ?', [session_id]);

            const [orders] = await pool.execute(
                `SELECT o.*, s.title, p.email as merchant_email 
                 FROM orders o 
                 JOIN services s ON o.service_id = s.id 
                 JOIN profiles p ON o.merchant_id = p.id 
                 WHERE o.stripe_session_id = ?`, 
                [session_id]
            );

            if (orders.length > 0) {
                const orderData = orders[0];
            // 📩 Send Email to Customer
            await resend.emails.send({
            from: 'ServiceHub <onboarding@resend.dev>', // Use your custom domain here later!
            to: [orderData.customer_email],
            subject: `Receipt for your booking: ${orderData.title}`,
            html: `<p>Thank you for your purchase!</p><p>You paid <strong>$${orderData.amount}</strong> for ${orderData.title}.</p><p>Order ID: ${orderData.id}</p>`
          });

// 📩 Send Email to Merchant
await resend.emails.send({
    from: 'ServiceHub <onboarding@resend.dev>',
    to: [orderData.merchant_email],
    subject: 'New Booking Confirmed!',
    html: `<p>Good news!</p><p>A customer (${orderData.customer_email}) booked your service: <strong>${orderData.title}</strong> for $${orderData.amount}.</p>`
});
               

               
            }

            res.status(200).json({ message: "Payment verified and receipts sent!" });
        } else {
            res.status(400).json({ error: "Payment was not successful" });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// ---------------- START SERVER ----------------
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
    console.log(`🚀 Marketplace API running on http://localhost:${PORT}`);
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use. Try changing the PORT in your .env file.`);
    } else {
        console.error('❌ Server Crash:', err.message);
    }
});